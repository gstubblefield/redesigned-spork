/*
 * animals.h
 *
 *  Created on: Feb 19, 2020
 *      Author: Garrett Stubblefield
 */

#ifndef ANIMALS_H_
#define ANIMALS_H_

#include <iostream>
using namespace std;

class Animal{
	public:
		string type;
		string subType;
		string name;
		int trackNum;
		int numberOfEggs;
		int nurse;

		void setName(string newName){
			name = newName;
		}

		void setTrackNum(int newNum){
			trackNum = newNum;
		}

		string getName(){
			return name;
		}

		int getTrackNum(){
			return trackNum;
		}
		virtual string getType()
		{
			return type;
		}
		virtual string getSubType()
		{
			return subType;
		}
		virtual int getNumberOfEggs()
		{
			return numberOfEggs;
		}
		virtual int getNurse()
		{
			return nurse;
		}
		virtual void PrintAnimal()
		{

		}


};

class Mammal : public Animal{
	public:
		string type = "Mammal";
		int nurse;
		int numberOfEggs = 0;

		void setNurse(int newNurse){
			nurse = newNurse;
		}

		int getNurse(){
			return nurse;
		}

		string getType(){
			return type;
		}
		int getNumberOfEggs()
		{
			return numberOfEggs;
		}

};

class Oviparous : public Animal{
	public:
		string type = "Oviparous";
		int numberOfEggs;
		int nurse = 0;

		void setNumberOfEggs(int newEggs){
			numberOfEggs = newEggs;
		}

		int getNumberOfEggs(){
			return numberOfEggs;
		}
		int getNurse()
		{
			return nurse;
		}

		string getType(){
			return type;
		}


};

class Crocodile : public Oviparous{
	public:
		string subType = "Crocodile";
		string getSubType(){
			return subType;
		}
		void PrintAnimal()
		{
			cout << endl << right << setw(6) << setfill('0') << trackNum;
			cout << " " << left << setw(15) << setfill(' ') <<  name;
			cout << " " << left << setw(15) << setfill(' ') << type;
			cout << " " << left << setw(15) << setfill(' ') << subType;
			cout << left << setw(6) << setfill(' ')<< numberOfEggs << nurse << endl;
		}


};

class Goose : public Oviparous{
	public:
		string getSubType(){
			return subType;
		}
		void PrintAnimal()
		{
			cout << endl << right << setw(6) << setfill('0') << trackNum;
			cout << " " << left << setw(15) << setfill(' ') <<  name;
			cout << " " << left << setw(15) << setfill(' ') << type;
			cout << " " << left << setw(15) << setfill(' ') << subType;
			cout << left << setw(6) << setfill(' ')<< numberOfEggs  << nurse << endl;
		}
	private:
		string subType = "Goose";
};

class Pelican : public Oviparous{
	public:
		string getSubType(){
			return subType;
		}
		void PrintAnimal()
		{
			cout << endl << right << setw(6) << setfill('0') << trackNum;
			cout << " " << left << setw(15) << setfill(' ') <<  name;
			cout << " " << left << setw(15) << setfill(' ') << type;
			cout << " " << left << setw(15) << setfill(' ') << subType;
			cout << left << setw(6) << setfill(' ')<< numberOfEggs  << nurse << endl;
		}
	private:
		string subType = "Pelican";
};

class Bat : public Mammal{
	public:
		string getSubType(){
			return subType;
		}
		void PrintAnimal()
		{
			cout << endl << right << setw(6) << setfill('0') << trackNum;
			cout << " " << fixed << left << setw(15) << setfill(' ') <<  name;
			cout << " " << left << setw(15) << setfill(' ') << type;
			cout << " " << left << setw(15) << setfill(' ') << subType;
			cout << left << setw(6) << setfill(' ')<< numberOfEggs << nurse << endl;
		}
	private:
		string subType = "Bat";
};

class Whale : public Mammal{
	public:
		string getSubType(){
			return subType;
		}
		void PrintAnimal()
		{
			cout << endl << right << setw(6) << setfill('0') << trackNum;
			cout << " " << left << setw(15) << setfill(' ') <<  name;
			cout << " " << left << setw(15) << setfill(' ') << type;
			cout << " " << left << setw(15) << setfill(' ') << subType;
			cout << left << setw(6) << setfill(' ')<< numberOfEggs << nurse << endl;
		}
	private:
		string subType = "Whale";
};

class SeaLion : public Mammal{
	public:
		string getSubType(){
				return subType;
		}
		void PrintAnimal()
		{
			cout << endl << right << setw(6) << setfill('0') << trackNum;
			cout << " " << left << setw(15) << setfill(' ') <<  name;
			cout << " " << left << setw(15) << setfill(' ') << type;
			cout << " " << left << setw(15) << setfill(' ') << subType;
			cout << left << setw(6) << setfill(' ')<< numberOfEggs  << nurse << endl;
		}
	private:
		string subType = "Sea Lion";
};

#endif /* ANIMALS_H_ */
