//============================================================================
// Name        : ProjectThree.cpp
// Author      : Garrett Stubblefield
// Version     : 1
// Copyright   : Your copyright notice
// Description : Zoo File System C++ with Java Integrated
//============================================================================

#include <iostream>
#include <jni.h>
#include <vector>
#include <iomanip>
#include "animals.h"
#include <fstream>
using namespace std;

void GenerateData()               //DO NOT TOUCH CODE IN THIS METHOD
{
     JavaVM *jvm;                      // Pointer to the JVM (Java Virtual Machine)
     JNIEnv *env;                      // Pointer to native interface
     //================== prepare loading of Java VM ============================
     JavaVMInitArgs vm_args;                        // Initialization arguments
     JavaVMOption* options = new JavaVMOption[1];   // JVM invocation options
     options[0].optionString = (char*) "-Djava.class.path=C:/Users/stubb/eclipse-workspace/ZooJava/bin";
     vm_args.version = JNI_VERSION_1_6;             // minimum Java version
     vm_args.nOptions = 1;                          // number of options
     vm_args.options = options;
     vm_args.ignoreUnrecognized = false;     // invalid options make the JVM init fail
     //=============== load and initialize Java VM and JNI interface =============
     jint rc = JNI_CreateJavaVM(&jvm, (void**)&env, &vm_args);  // YES !!
     delete options;    // we then no longer need the initialisation options.
     if (rc != JNI_OK) {
            // TO DO: error processing...
            cin.get();
            exit(EXIT_FAILURE);
     }
     //=============== Display JVM version =======================================
     cout << "JVM load succeeded: Version ";
     jint ver = env->GetVersion();
     cout << ((ver >> 16) & 0x0f) << "." << (ver & 0x0f) << endl;

     jclass cls2 = env->FindClass("ZooFileWriter");  // try to find the class
     if (cls2 == nullptr) {
            cerr << "ERROR: class not found !";
     }
     else {                                  // if class found, continue
            cout << "Class MyTest found" << endl;
            jmethodID mid = env->GetStaticMethodID(cls2, "createZooFile", "()V");  // find method
            if (mid == nullptr)
                   cerr << "ERROR: method void createZooFile() not found !" << endl;
            else {
                   env->CallStaticVoidMethod(cls2, mid);                      // call method
                   cout << endl;
            }
     }


     jvm->DestroyJavaVM();
     cin.get();
}

// Add Animal Data from user to Animal Vector(Parameter)
void AddAnimal(vector<Animal *> &AnimalList)
{
	// Obj Pointer for Classes tha Inheirit from Animal Class and Oviparous/Mammal
	Crocodile* crocPtr = nullptr;
	Goose* goosePtr = nullptr;
	Pelican* pelicanPtr = nullptr;
	Bat* batPtr = nullptr;
	Whale* whalePtr = nullptr;
	SeaLion* seaLionPtr = nullptr;

	// Const string arrays with each subtype;
	const string OVISUBTYPES[] = {"Crocodile", "Goose", "Pelican"};
	const string MAMSUBTYPES[] = {"Bat", "Whale", "Sea Lion"};

	string name = "";		// string to hold name from user
	int tracker = -1;		// int to hold tracker number from user
	bool duplicate = false;	// bool to check for duplicate Animal with tracker number
	string newType = "";	// string to hold type of Animal either Oviparous/Mammal
	int typeChoice = -1;	// int to take in type chocie either 1 or 2
    string newSubType = "";	// string to hold sub type from const string array's
    int subChoice;			// int to hold sub type choice
    int newNurse;			// int to take in nurse choice from user
    int newEggs;			// int to take in the number of eggs from user
    int index = 0;			// index to use for what sub type was used to send data to correct sub type
    int size = AnimalList.size();	// set size of vector to loop through
    int addIn = 0;			// choice for user to validate

    // while duplicate bool is false take in tracker number.
    while(!duplicate)
    {
    	 cout << "Enter Tracking Number:(0-10000)\n";
    	 cin >> tracker;

    	 // Check to make sure the number is within range
    	 while(tracker < 0 || tracker >= 1000000)
    	 {
         	cout << "\nERROR Tracker Number is out of range\n";
   	       	cin >> tracker;
    	 }

    	// Loop through all tracking numbers to see if there is a duplicate
        for(int i = 0; i < size; i++)
       	{
        	// If duplicate found a duplicate tracking number set to -1 to loop again
      		if(AnimalList.at(i)->getTrackNum() == tracker)
      		{
     			cout << "This tracking number is already in the system. Please enter a unique number.\n";
     			tracker = -1;
        	}

       	}
        // This means there is not a duplicate tracking number and will break while loop
        if(tracker != -1)
        {
    	   duplicate = true;
        }

   }

    // Get Name from user
	cout << "Enter Name:";
    cin >> name;

    // Validate name is the not longer than 15 characters
    while(name.length() > 15){
    	cout << "\nEnter a name with max 15 characters.\n";
    	getline(cin, name);
    }


    // Get Type of Animal from user. Menu Choice
    cout << "Please Enter number for  the Type of Animal\n(1)Oviparous\n(2)Mammal\n";
    cin >> typeChoice;

    // Validate that either a 1 or 2 was entered
    while(!cin || typeChoice < 1 || typeChoice > 2){
    	cout << "Error Please Enter 1 for Oviparous or 2 for Mammal ";
    	cin >> typeChoice;
    }

    // Set Type of Animal based on menu choice
    // If type choice was for Oviparous
    if(typeChoice == 1){
    	newType = "Oviparous";

    	// Take in Name from user
    	cout << "\nPlease Enter the animals sub type\n(1)Crocodile\n(2)Goose\n(3)Pelican\n";
    	cin >> subChoice;

    	// Validate Choice
    	while(!cin || subChoice < 1 || subChoice > 3){
       		cout << "\nPlease Enter the animals sub type\n(1)Crocodile\n(2)Goose\n(3)Pelican\n";
 	    	cin >> subChoice;
       	}

    	newSubType = OVISUBTYPES[subChoice -1];		// Set subType choice to const array OVISUBTypes index at menuCHoice -1

    	// Get number of eggs from the user
    	cout << "\nEnter the number of Eggs laid ";
    	cin >> newEggs;

    	// Validate eggs int
    	while(!cin || newEggs < 0){
    		cout << "\nERROR! Enter the number of Eggs laid ";
    		cin >> newEggs;
    	}

    }
    else if(typeChoice ==2){		// If Type choice was Mammal
    	newType = "Mammal";
    	newEggs = 0;

    	// Get sub type form user
    	cout << "\nPlease Enter the animals sub type\n(1)Bat\n(2)Whale\n(3)Sea Lion\n";
    	cin >> subChoice;

    	// Validate sub type choice
    	while(!cin || subChoice < 1 || subChoice > 3){
       		cout << "\nPlease Enter the animals sub type\n(1)Bat\n(2)Whale\n(3)Sea Lion\n";
       		cin >> subChoice;
    	 }

    	newSubType = MAMSUBTYPES[subChoice -1];

    	// Get Nursing Choice from user Eggs is set to 0 in class
    	cout << "\nIs the Animal Nursing? Enter (1) for Yes (0) for No.\n";
    	cin >> newNurse;

    	// validate nuring choice from menu
    	while(!cin || newNurse < 0 || newNurse > 1){
    		cout << "Error! Enter a 1 for Nursing 0 for Not Nursing\n";
    		cin >> newNurse;
    	}
    }

    // Set Index form switch statement
    if(typeChoice == 1){
    	index = subChoice - 1;
    }
    else if(typeChoice == 2)
    {
    	index = subChoice + 2;
    }

    // See if user wants to add in the Animal to Data base
    cout << " Would you like to add this Animal into the database?\n(1)Yes\n(2)No\n";
    cin >> addIn;

    // Validate the user addIn choice
    while(addIn < 1 || addIn > 2)
    {
    	cout << "\nERROR! Invalid Choice\n";
    	cin >> addIn;
    }

    // Switch Statement for correct class/object type
    // Each case adds the data then adds oject to AnimalList vector
    switch(index){
    case 0:
    	//cout << "Added a Croc";
    	crocPtr = new Crocodile;
    	crocPtr->setTrackNum(tracker);
    	crocPtr->setName(name);
    	crocPtr->setNumberOfEggs(newEggs);
  		AnimalList.push_back(crocPtr);
  		break;
    case 1:
    	//cout << "Added a Goose";
    	goosePtr = new Goose;
    	goosePtr->setTrackNum(tracker);
    	goosePtr->setName(name);
    	goosePtr->setNumberOfEggs(newEggs);
   		AnimalList.push_back(goosePtr);
      	break;
    case 2:
    	//cout << "Added a Pelican";
    	pelicanPtr = new Pelican;
    	pelicanPtr->setTrackNum(tracker);
    	pelicanPtr->setName(name);
    	pelicanPtr->setNumberOfEggs(newEggs);
    	AnimalList.push_back(pelicanPtr);
    	break;
    case 3:
    	//cout << "Added a Bat";
    	batPtr = new Bat;
    	batPtr->setTrackNum(tracker);
    	batPtr->setName(name);
    	batPtr->setNurse(newNurse);
    	AnimalList.push_back(batPtr);
    	break;
    case 4:
    	//cout << "Added a Whale";
    	whalePtr = new Whale;
    	whalePtr->setTrackNum(tracker);
    	whalePtr->setName(name);
    	whalePtr->setNurse(newNurse);
    	AnimalList.push_back(whalePtr);
    	break;
    case 5:
    	//cout << "Added a Sea Lion";
    	seaLionPtr = new SeaLion;
    	seaLionPtr->setTrackNum(tracker);
    	seaLionPtr->setName(name);
    	seaLionPtr->setNurse(newNurse);
    	AnimalList.push_back(seaLionPtr);

    }

    cout << "\nAnimal Added\n";

}


// Remove Animal from vector
void RemoveAnimal(vector<Animal *> &AnimalList)
{
	int trackerDelete = -1;			// int for tracker number to delete
	int trackerIndex = -1;			// index for when tracker number is found

	// Get tracking number from User
    cout << "\nEnter tracker number for the animal";
    cin >> trackerDelete;

    // save size of vector to search for tracking number
    int size = AnimalList.size();

    // Validate tracking number choice
    while(trackerDelete < 0 || trackerDelete > 1000000)
    {
    	cout << "\nERROR Tracker Number is out of range\n";
    	cin >> trackerDelete;
    }

    for(int i = 0; i < size; i++)
    {
    	if(AnimalList.at(i)->getTrackNum() == trackerDelete)
    	{
    		cout << "\nAnimal Found!\n";
    		trackerIndex = i;
			break;
    	}
    }

    // Make sure user wants to delete the animal
    cout << "\n Would you like to delete the following animal\n(1)Yes or (2)No\n";
    AnimalList.at(trackerIndex)->PrintAnimal();
    cin >> trackerDelete;

    // Delete Animal if user wants to
    if(trackerDelete == 1)
    {
    	AnimalList.erase(AnimalList.begin() + (trackerIndex));
    }

    // Tell user animal was successfully deleted
    cout << "\nAniaml Successfully deleted\n";

}

// Load in the array from the file
void LoadDataFromFile(vector<Animal *> &AnimalList)
{
	// all sub types in cost array
	const string SUBTYPES[] = {"Crocodile", "Goose", "Pelican","Bat", "Whale", "Sea Lion"};

	// ptr objects for each sublass
    Crocodile* crocPtr = nullptr;
    Goose* goosePtr = nullptr;
   	Pelican* pelicanPtr = nullptr;
   	Bat* batPtr = nullptr;
   	Whale* whalePtr = nullptr;
   	SeaLion* seaLionPtr = nullptr;


   	// open file to read from
    ifstream inFS;
    inFS.open("zoodata.txt");

    // do while file is taking in new data
    do {
    	// Variables to take in data from
    	int trackIn, eggsIn, nurseIn;
    	 string nameIn ="";
    	 string typeIn = "";
    	 string subIn = "";
    	 bool match = false;  // bool to make sure it has a correct sub type
    	 int x = 0;

    	  // read in the correct variables in this order
    	  inFS >> trackIn;
    	  inFS >> nameIn;
   		  inFS >> typeIn;
   		  inFS >> subIn;
   		  inFS >> eggsIn;
   		  inFS >> nurseIn;


   		  // while there is no matching subtype
          while(!match){

        	  if(subIn.compare(SUBTYPES[x]) == 0)
        	  {
        		  match = true;
        	  }
        	  else
        	  {
        		  x++;
        	  }
        	  if(x > 6)			// break loop if gone through all subtypes
        	  {
        		  match = true;
        		  x = -1;
        	  }
          }

          // Switch case for all the subtypes none added if wrong subtype entered
          switch(x){
              case 0:
              	cout << "Added a Croc\n";
              	crocPtr = new Crocodile;
              	crocPtr->setTrackNum(trackIn);
              	crocPtr->setName(nameIn);
              	crocPtr->setNumberOfEggs(eggsIn);
            	AnimalList.push_back(crocPtr);
            	break;
              case 1:
              	cout << "Added a Goose\n";
              	goosePtr = new Goose;
              	goosePtr->setTrackNum(trackIn);
              	goosePtr->setName(nameIn);
              	goosePtr->setNumberOfEggs(eggsIn);
             	AnimalList.push_back(goosePtr);
               	break;
              case 2:
              	cout << "Added a Pelican\n";
              	pelicanPtr = new Pelican;
              	pelicanPtr->setTrackNum(trackIn);
              	pelicanPtr->setName(nameIn);
              	pelicanPtr->setNumberOfEggs(eggsIn);
              	AnimalList.push_back(pelicanPtr);
              	break;
              case 3:
              	cout << "Added a Bat\n";
              	batPtr = new Bat;
              	batPtr->setTrackNum(trackIn);
              	batPtr->setName(nameIn);
              	batPtr->setNurse(nurseIn);
              	AnimalList.push_back(batPtr);
              	break;
              case 4:
              	cout << "Added a Whale\n";
              	whalePtr = new Whale;
              	whalePtr->setTrackNum(trackIn);
              	whalePtr->setName(nameIn);
              	whalePtr->setNurse(nurseIn);
              	AnimalList.push_back(whalePtr);
              	break;
              case 5:
              	cout << "Added a Sea Lion\n";
              	seaLionPtr = new SeaLion;
              	seaLionPtr->setTrackNum(trackIn);
              	seaLionPtr->setName(nameIn);
              	seaLionPtr->setNurse(nurseIn);
              	AnimalList.push_back(seaLionPtr);

              }


       }while (!inFS.eof());

    cout << "\nLoad Complete\n";


    inFS.close();
}

// Save Data to output file
void SaveDataToFile(vector<Animal *> &AnimalList)
{
	// Set size for vector for looping
	int size = AnimalList.size();

	ofstream outFS;

	// open output file
	outFS.open("zoodata.txt");

	if (!outFS.is_open()) // if the file could not open
	{
		cout << "Could not open file myoutfile.txt." << endl;

	}
	else
	{
		// loop through each object adding in the data from the subclasses
		for(int i = 0; i < size; i++)
		{
			outFS << right << setfill('0') << setw(6) <<  AnimalList.at(i)->getTrackNum() << " ";
			outFS << left <<  setw(15) << setfill(' ') << AnimalList.at(i)->getName() << " ";
			outFS << left <<  setw(15) << setfill(' ') << AnimalList.at(i)->getType() << " ";
			outFS << left <<  setw(15) << setfill(' ') << AnimalList.at(i)->getSubType() << " ";
			outFS << AnimalList.at(i)->getNumberOfEggs()<<" ";
			outFS << AnimalList.at(i)->getNurse() << endl;
		}
	}

	// Close output file and tell user success
	outFS.close();
	cout << "\nSave Successfully completed\n";
}

// Display Menu choices for the main menu return the choice
int DisplayMenu()
{
	int menuChoice = 0;

	// Give choices to user and take in the choice
	cout << "(1)Load Animal Data\n(2)Generate Data\n(3)Display Animal Data\n(4)Add Record\n(5)Delete Record\n(6)Save Animal Data\n(7)Exit\n";
	cin >> menuChoice;

	// Validate the choice
	while(menuChoice < 1 || menuChoice >7)
	{
		cout << "ERROR! Enter choice from menu above";
		cin >> menuChoice;
	}
	cout << endl;

    return menuChoice; // Return the choice
}

// Display all Animals in a neat table
void DisplayAnimals(vector<Animal *> &AnimalList)
{
	// Set variables for header of the columns
	string disName = "Name";
	string disType = " Type";
	string disSubType = " Sub Type";
	int size = AnimalList.size();		// Set size of the vector of all objects

	// output the header column names
	cout << endl << "Track#";
	cout << " " << left << setw(15) << setfill(' ') <<  disName;
	cout << left << setw(15) << setfill(' ') << disType;
	cout << left << setw(15) << setfill(' ') << disSubType;
	cout << "Eggs" << " " << " Nurse" << endl;


	// print the data from the vector
	for(int i = 0; i < size; i++)
	{
		AnimalList.at(i)->PrintAnimal();
	}
}

// Main funtion
int main()
{
	// Create vector of type animal called AnimalList
	vector<Animal*> AnimalList;


	bool exit = false; // exit bool to terminate program

	// while choice is not to exit
	while(!exit)
	{
		int choice = DisplayMenu();
		switch(choice)
		{
		case 1:
			LoadDataFromFile(AnimalList);
			break;
		case 2:
			GenerateData();
			break;
		case 3:
			DisplayAnimals(AnimalList);
			break;
		case 4:
			AddAnimal(AnimalList);
			break;
		case 5:
			RemoveAnimal(AnimalList);
			break;
		case 6:
			SaveDataToFile(AnimalList);
			break;
		case 7:
			exit = true;
			break;
		}

	}

	return 0;
}
